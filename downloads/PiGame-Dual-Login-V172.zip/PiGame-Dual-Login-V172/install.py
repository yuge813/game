#!/usr/bin/env python3
"""Install the two-button overlay for the deployed PiGame V1.7.1 login page."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', default='/www/wwwroot/pibi.xin')
parser.add_argument('--php')
parser.add_argument('--apply', action='store_true', help='write changes after verification')
args = parser.parse_args()
root = Path(args.root).resolve(strict=True)
asset_name = 'assets/pi-login/pi-dual-login-v172.js'
old_name = 'assets/pi-login/pi-dual-login.js'
view_name = 'assets/includes/pi-access-view.php'
old_hash = '6a2b4051d69cee277d89acf0b11869f13392e7de0818c6ba6c37eef8da8b8cb8'
new_hash = '0b08253f22e83dc786a180d2b35e5e91e632705f2f66142de31486bfd76f6f92'
old_script = b"pi-dual-login.js?v=1.7.1"
new_script = b"pi-dual-login-v172.js?v=1.7.2"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def target(name):
    path = root / name
    if path.resolve() != path or path.is_symlink() or (path.exists() and not path.is_file()):
        raise SystemExit('FAILED: unexpected path ' + str(path))
    return path

asset = target(asset_name)
view = target(view_name)
old_asset = target(old_name)
if digest(old_asset.read_bytes()) != old_hash:
    raise SystemExit('FAILED: deployed V1.7.1 login script differs from the tested version.')
if not target('pi-signin.php').is_file():
    raise SystemExit('FAILED: system-browser callback is missing.')
package = Path(__file__).resolve().parent
code = (package / asset_name).read_bytes()
if digest(code) != new_hash:
    raise SystemExit('FAILED: package asset checksum differs.')
if asset.exists() and asset.read_bytes() != code:
    raise SystemExit('FAILED: a different pi-dual-login-v172.js already exists.')

source = view.read_bytes()
if source.count(b'id="pi-system-signin"') != 1:
    raise SystemExit('FAILED: expected exactly one system-browser link.')
if source.count(new_script) == 1 and old_script not in source and asset.exists():
    raise SystemExit(print('APPLY PASS: already installed'))
if source.count(old_script) != 1 or new_script in source:
    raise SystemExit('FAILED: V1.7.1 template script reference does not match.')
updated = source.replace(old_script, new_script, 1)
php = args.php or ('/www/server/php/83/bin/php' if os.access('/www/server/php/83/bin/php', os.X_OK) else shutil.which('php'))
if not php:
    raise SystemExit('FAILED: PHP CLI not found.')
with tempfile.TemporaryDirectory(prefix='pi-dual-lint-') as tmp:
    candidate = Path(tmp) / 'view.php'
    candidate.write_bytes(updated)
    subprocess.run([php, '-l', str(candidate)], check=True)
if not args.apply:
    raise SystemExit(print('CHECK PASS: site files unchanged'))

def atomic(path, data, reference):
    meta = reference.stat()
    desc, tmp = tempfile.mkstemp(prefix='.pi-dual-', dir=path.parent)
    try:
        with os.fdopen(desc, 'wb') as file:
            local = os.fstat(file.fileno())
            if (local.st_uid, local.st_gid) != (meta.st_uid, meta.st_gid):
                os.fchown(file.fileno(), meta.st_uid, meta.st_gid)
            os.fchmod(file.fileno(), meta.st_mode & 0o777)
            file.write(data)
            file.flush()
            os.fsync(file.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)

backup = Path(tempfile.mkdtemp(prefix='pi-dual-v172-', dir='/tmp'))
shutil.copy2(view, backup / view.name)
if view.read_bytes() != source:
    raise SystemExit('FAILED: login page changed during installation.')
if not asset.exists():
    atomic(asset, code, old_asset)
atomic(view, updated, view)
print('BACKUP:', backup / view.name)
print('APPLY PASS: both login options use the V1.7.2 page script.')
