/* PiGame v1.7.0: Pi SDK identity, verified without any app login cookie. */
(function(){
'use strict';
const button=document.getElementById('pi-login-button');
const status=document.getElementById('pi-login-status');
const boot=document.getElementById('gps-pi-bootstrap');
if(!button||!status||!boot)return;
const label=button.querySelector('.pi-access-action-label');
const originalLabel=label?label.textContent:'';
let config;
try {config=JSON.parse(boot.textContent); if(new URL(config.endpoint).origin!==location.origin)throw Error('origin');}
catch(_){show('登录页面配置无效，请联系管理员。',true);return;}
let processing=false;
let verified=false;
function show(text,error){status.hidden=false;status.classList.toggle('is-error',!!error);status.textContent=text;}
button.addEventListener('click',async function(){
  if(processing||verified)return;
  processing=true;button.disabled=true;
  if(label)label.textContent='正在核验 Pi 身份…';
  try {
    if(!window.Pi||typeof Pi.authenticate!=='function')throw Error('请在 Pi Browser 中打开本站登录。');
    if(typeof Pi.init==='function')await Promise.resolve(Pi.init({version:'2.0',sandbox:config.sandbox===true}));
    show('正在通过 Pi 官方授权验证账号…',false);
    const result=await Pi.authenticate(['username'],function(){});
    if(!result||typeof result.accessToken!=='string'||!result.accessToken)throw Error('Pi 授权未成功，请重试。');
    const response=await fetch('/pi-stateless.php',{method:'POST',cache:'no-store',credentials:'omit',
      headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'verify',accessToken:result.accessToken})});
    const data=await response.json();
    if(!response.ok||data.authenticated!==true)throw Error(data.message||'服务器未能验证你的 Pi 身份。');
    // Keep the verified view in the same WebView after native authorization.
    // Reloading here loses the in-memory login result and the SDK must authenticate again.
    show('Pi 登录成功：'+String(data.username||'Pi 用户'),false);
    verified=true;
    button.hidden=true;
    const external=document.getElementById('pi-system-signin');
    if(external)external.hidden=true;
    const copy=document.getElementById('pi-copy-link');
    if(copy)copy.hidden=true;
    const next=new URL(config.endpoint).searchParams.get('next')||'/';
    const game=/^\/game\/[A-Za-z0-9_-]{1,180}$/.test(next);
    const enter=document.createElement('a');
    enter.className='pi-access-action';
    enter.href=game?next:'/';
    enter.textContent=game?'进入游戏':'进入游戏首页';
    status.insertAdjacentElement('afterend',enter);
    // Native authorization can resolve while the site's WebView is backgrounded.
    // Navigate once the original page is visible again.
    let returning=false;
    function returnToSite(){
      if(document.hidden||returning)return;
      returning=true;
      document.removeEventListener('visibilitychange',returnToSite);
      window.removeEventListener('pageshow',returnToSite);
      window.location.replace(enter.href);
    }
    document.addEventListener('visibilitychange',returnToSite);
    window.addEventListener('pageshow',returnToSite);
    returnToSite();
  } catch(err){
    const message=String(err&&err.message||'');
    show(/cancel|declin|denied|reject/i.test(message)?'已取消 Pi 授权，可以重新登录。':(message||'登录失败，请重试。'),true);
  } finally {
    processing=false;button.disabled=false;
    if(label)label.textContent=originalLabel;
  }
});
})();

/* PiGame dual login: the system-browser link is independent of the Pi login button. */
(function () {
    'use strict';
    const link = document.getElementById('pi-system-signin');
    if (!link) return;
    const destination = new URL(link.href, window.location.href);
    if (destination.origin !== window.location.origin ||
        destination.pathname !== '/pi-signin.php' ||
        destination.searchParams.get('start') !== '1') return;

    let opening = false;
    let useBrowserLink = false;
    link.addEventListener('click', async function (event) {
        const sdk = window.Pi;
        const insidePi = window.top !== window.self || /Pi[ -]?Browser/i.test(navigator.userAgent);
        if (event.defaultPrevented || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey ||
            !insidePi || useBrowserLink || typeof sdk?.openUrlInSystemBrowser !== 'function') return;
        event.preventDefault();
        if (opening) return;
        opening = true;
        let timeout;
        try {
            const boot = document.getElementById('gps-pi-bootstrap');
            const config = JSON.parse(boot?.textContent || '{}');
            await Promise.race([
                (async () => {
                    if (typeof sdk.init === 'function') await sdk.init({version: '2.0', sandbox: config.sandbox === true});
                    if (useBrowserLink) return;
                    await sdk.openUrlInSystemBrowser(destination.href);
                })(),
                new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('Pi SDK timeout')), 5000); }),
            ]);
        } catch (_) {
            useBrowserLink = true;
            const notice = document.getElementById('pi-login-status');
            if (notice) {
                notice.hidden = false;
                notice.classList.add('is-error');
                notice.textContent = '未能自动打开系统浏览器。可长按此登录链接复制地址，再粘贴到 Safari 或 Chrome 中打开。';
            }
        } finally {
            clearTimeout(timeout);
            opening = false;
        }
    });
})();
